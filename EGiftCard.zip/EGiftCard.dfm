object frmEGiftCard: TfrmEGiftCard
  Left = 0
  Top = 0
  Caption = 'EGiftCard'
  ClientHeight = 212
  ClientWidth = 213
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  Position = poScreenCenter
  TextHeight = 13
  object lblTerminalID: TLabel
    Left = 8
    Top = 8
    Width = 54
    Height = 13
    Caption = 'Terminal ID'
  end
  object lblTransactionID: TLabel
    Left = 8
    Top = 35
    Width = 70
    Height = 13
    Caption = 'Transaction ID'
  end
  object lblAmount: TLabel
    Left = 8
    Top = 62
    Width = 46
    Height = 13
    Caption = 'Amount $'
  end
  object edtTerminalID: TEdit
    Left = 84
    Top = 5
    Width = 121
    Height = 21
    TabOrder = 0
    Text = 'edtTerminalID'
  end
  object edtTransactionID: TEdit
    Left = 84
    Top = 32
    Width = 121
    Height = 21
    TabOrder = 1
    Text = 'edtTransactionID'
  end
  object edtAmount: TEdit
    Left = 84
    Top = 59
    Width = 121
    Height = 21
    NumbersOnly = True
    TabOrder = 2
    Text = '100'
  end
  object mResponse: TMemo
    Left = 8
    Top = 126
    Width = 197
    Height = 75
    Lines.Strings = (
      'Result Text: OK'
      'Txn error: 0'
      'Barcode: 9014123456789'
      'PIN: 1234'
      'Balance: $0.00')
    TabOrder = 3
  end
  object btnSend: TButton
    Left = 64
    Top = 86
    Width = 75
    Height = 25
    Caption = 'Send'
    TabOrder = 4
    OnClick = btnSendClick
  end
end

unit EGiftCard;

interface

uses
  Winapi.Windows,
  Winapi.Messages,
  System.SysUtils,
  System.Variants,
  System.Classes,
  System.UITypes,
  Vcl.Graphics,
  Vcl.Controls,
  Vcl.Forms,
  Vcl.Dialogs,
  Vcl.StdCtrls,
  Vcl.ExtCtrls,
  System.DateUtils,
  Xml.XMLIntf, Xml.XMLDoc, IdHTTP, IdSSLOpenSSL;

const
  ENDPOINT_URL = 'https://yourapi.endpoint/';
  APITYPE = 'SALE';
  APIMODE = 'DIGITAL';
  USERNAME = 'FSSI-UAT';
  SIGNATURE = 'abc123';
  PRODUCT_ID = '9421009560110'; //egiftcard product ID

type
  TfrmEGiftCard = class(TForm)
    btnSend: TButton;
    edtAmount: TEdit;
    edtTerminalID: TEdit;
    edtTransactionID: TEdit;
    lblAmount: TLabel;
    lblTerminalID: TLabel;
    lblTransactionID: TLabel;
    mResponse: TMemo;

    procedure btnSendClick(Sender: TObject);
    function CreateXMLRequest: TXMLDocument;
    function SendXMLRequest(XML: TXMLDocument; const URL: string): string;
    procedure ParseXMLResponse(const XMLResponse: string);

  private
    { Private declarations }

  public
    { Public declarations }

  end;

var
  frmEGiftCard: TfrmEGiftCard;

implementation

{$R *.dfm}

procedure TfrmEGiftCard.btnSendClick(Sender: TObject);
var
  XMLRequest: TXMLDocument;
  XMLResponse: string;
begin
  XMLRequest := CreateXMLRequest;
  if XMLRequest.Active then
  begin
    XMLResponse := SendXMLRequest(XMLRequest, ENDPOINT_URL);
    ParseXMLResponse(XMLResponse);
  end;
end;

function TfrmEGiftCard.CreateXMLRequest: TXMLDocument;
var
  RootNode, AuthNode: IXMLNode;
begin
  Result := TXMLDocument.Create(Self);
  Result.Options := [doNodeAutoIndent];
  Result.Version := '1.0';
  Result.Encoding := 'utf-8';
  Result.Active := False;

  if edtTerminalID.Text = '' then
  begin
    ShowMessage('Error: Terminal ID is empty');
    Exit;
  end;

  if edtTransactionID.Text = '' then
  begin
    ShowMessage('Error: Transaction ID is empty');
    Exit;
  end;

  Result.Active := True;

  // Add root element
  RootNode := Result.AddChild('REQUEST');
  RootNode.Attributes['TYPE'] := APITYPE; //'SALE'
  RootNode.Attributes['MODE'] := APIMODE; //'DIGITAL'

  // Add AUTHORIZATION
  AuthNode := RootNode.AddChild('AUTHORIZATION');
  AuthNode.AddChild('USERNAME').Text := USERNAME;
  AuthNode.AddChild('SIGNATURE').Text := SIGNATURE;

  // Add other elements
  RootNode.AddChild('TERMINALID').Text := edtTerminalID.Text;
  RootNode.AddChild('TXID').Text := edtTransactionID.Text;
  RootNode.AddChild('LOCALDATETIME').Text := FormatDateTime('yyyy-mm-dd hh:nn:ss', Now);
  RootNode.AddChild('CURRENCY').Text := 'NZD';
  RootNode.AddChild('AMOUNT').Text := (strToInt(edtAmount.Text) * 100).ToString; //cents
  RootNode.AddChild('PRODUCTID').Text := PRODUCT_ID;
end;

function TfrmEGiftCard.SendXMLRequest(XML: TXMLDocument; const URL: string): string;
var
  HTTP: TIdHTTP;
  SSLHandler: TIdSSLIOHandlerSocketOpenSSL;
  RequestStream, ResponseStream: TStringStream;
begin
  HTTP := TIdHTTP.Create(nil);
  SSLHandler := TIdSSLIOHandlerSocketOpenSSL.Create(HTTP);
  RequestStream := TStringStream.Create(XML.XML.Text, TEncoding.UTF8);
  ResponseStream := TStringStream.Create;
  try
    HTTP.IOHandler := SSLHandler;
    HTTP.Request.ContentType := 'application/xml';
    HTTP.Post(URL, RequestStream, ResponseStream);
    Result := ResponseStream.DataString;
  finally
    HTTP.Free;
    SSLHandler.Free;
    RequestStream.Free;
    ResponseStream.Free;
  end;
end;

procedure TfrmEGiftCard.ParseXMLResponse(const XMLResponse: string);
var
  XMLDoc: TXMLDocument;
  RootNode, BalanceNode, PinCredentialsNode: IXMLNode;
begin
  XMLDoc := TXMLDocument.Create(nil);
  XMLDoc.LoadFromXML(XMLResponse);
  XMLDoc.Active := True;
  mResponse.Lines.Clear;

  RootNode := XMLDoc.DocumentElement;
  if Assigned(RootNode) and (RootNode.NodeName = 'RESPONSE') then
  begin
    // Extract basic fields
    mResponse.Lines.Add('Result Text: ' + RootNode.ChildNodes['RESULTTEXT'].Text); //should be "ok"
    mResponse.Lines.Add('Txn error: ' + RootNode.ChildNodes['TXNERROR'].Text); //should be blank
    //mResponse.Lines.Add('Amount: ' + RootNode.ChildNodes['AMOUNT'].Text); //amount loaded, use balance instead

    // Access nested nodes
    PinCredentialsNode := RootNode.ChildNodes['PINCREDENTIALS'];
    if Assigned(PinCredentialsNode) then
    begin
      //mResponse.Lines.Add('PIN: ' + PinCredentialsNode.ChildNodes['PIN'].Text); //DCPZQVGL9740286132
      mResponse.Lines.Add('Barcode: ' + PinCredentialsNode.ChildNodes['SERIAL'].Text); //this is the barcode
      mResponse.Lines.Add('PIN: ' + PinCredentialsNode.ChildNodes['SCODE'].Text); //this is the pin
    end;

    BalanceNode := RootNode.ChildNodes['BALANCE'].ChildNodes['CURRENCY'];
    if Assigned(BalanceNode) then
    begin
      mResponse.Lines.Add('Balance: $' + (StrToInt(BalanceNode.ChildNodes['BALANCE'].Text) / 100).ToString); //convert cents to dollars
    end;
  end;
end;

initialization

finalization

end.
